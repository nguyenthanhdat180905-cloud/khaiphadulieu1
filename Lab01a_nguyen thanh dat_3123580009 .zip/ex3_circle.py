# Nhập bán kính r
r = float(input("Nhập bán kính r: "))

# Định nghĩa giá trị của π
pi = 3.1416

# Tính chu vi (cv) và diện tích (dt)
cv = 2 * pi * r
dt = pi * r * r 

# In kết quả
print(f"Chu vi của hình tròn là: {cv:.2f}")
print(f"Diện tích của hình tròn là: {dt:.2f}")
